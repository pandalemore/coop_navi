
package control;

import dbbeans.*;

import connection.DataAccess;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;




public class Control extends HttpServlet
{
    private DataAccess db;
    
    //public static DataAccess dbtest;
    //private static String logginModeratorTest = "";
    //private String logginModerator = "argh";
    
   //static String login_mid_s2;
   // static int login_mid;


    
    private void processAction(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException
    {
            HttpSession s = request.getSession(true);
   
            
            String student_name = (String)request.getParameter("txtLname");
            
            String moderator_lname = (String)request.getParameter("txtMlname");
            String moderator_fname = (String)request.getParameter("txtMfname");
            
            //String login_mid_s = (String)request.getParameter("login_mid");
            //login_mid_s2 = login_mid_s;
            //int login_mid = Integer.valueOf(login_mid_s);
            
            
            
            String company_name = (String)request.getParameter("txtCpname");


            


            //STUDENT
            StudentBean studentbean = new StudentBean();

            db= new DataAccess();
            db.openConnection();
            
            studentbean.setDataAccess(db);

//            int sid = studentbean.existsStudent(student_name, db);
//
//            if (sid == -1)
//            {
//                sid = studentbean.insertStudent(student_name, db);
//            }
//
//            studentbean.setlName(student_name);
//            studentbean.setSid(sid);
//
//            s.setAttribute("studentbean", studentbean );
            
            
            /*if (!studentbean.existsStudent(custid, artist_name, db)){
                likeartistbean.insertLikeArtist(custid, artist_name, db);
            }*/

            
            
            s.setAttribute("studentbean", studentbean );
            s.setAttribute("dataaccess",db);
            s.setAttribute("db",db);
            
            


            //MODERATOR
            ModeratorBean moderatorbean = new ModeratorBean();
            
            db= new DataAccess();
            db.openConnection();
            
            moderatorbean.setDataAccess(db);
            
            


                //int mid = moderatorbean.existsModerator("Wa", db);
//                int mid = moderatorbean.existsModerator(moderator_lname, db);
//
//                if (mid == -1)
//                {
//                    mid = moderatorbean.insertModerator(moderator_fname, moderator_lname, db);
//                    //mid = moderatorbean.insertModerator("Aa", "Wa", db);
//                }
//
//                moderatorbean.setMLName(moderator_lname);
//                moderatorbean.setMFName(moderator_fname);
//                moderatorbean.setMid(mid);
                
                
                
                
//                String login_mid_s = (String)request.getParameter("login_mid");
//                System.out.println("mid s");
//                System.out.println(login_mid_s);
//                
//                int login_mid = Integer.valueOf(login_mid_s);
//                System.out.println("mid");
//                System.out.println(login_mid);
//                
//                logginModerator = moderatorbean.getLogginModerator(login_mid, db);
//                System.out.println("list");
//                System.out.println(logginModerator);
                
                
                

               

                s.setAttribute("moderatorbean", moderatorbean );
                s.setAttribute("dataaccess", db);
                s.setAttribute("db", db);
                
                
//            db= new DataAccess();
//            db.openConnection();
//            
//            //moderatorbean.insertModerator("Anbo", "Wang", db);
//            //moderatorbean.setMFName("Anbo");
//            //moderatorbean.setMLName("Wang");
//
//            int mid = moderatorbean.existsModerator("Wa", db);
//
//            if (mid == -1)
//            {
//                //mid = moderatorbean.insertModerator(moderator_fname, moderator_lname, db);
//                mid = moderatorbean.insertModerator("Aa", "Wa", db);
//            }
//
//            moderatorbean.setMLName("Wa");
//            moderatorbean.setMFName("Aa");
//            moderatorbean.setMid(mid);
//
//            s.setAttribute("moderatorbean", moderatorbean );
//            s.setAttribute("dataaccess", db);
//            s.setAttribute("db", db);
            
            
//            if (!moderatorbean.existsModerator(moderator_lname, db)){
//                moderatorbean.insertModerator(moderator_fname, moderator_lname, db);
//            }
//
//            moderatorbean.setDataAccess(db);
//            
//            s.setAttribute("moderatorbean", moderatorbean );
//            s.setAttribute("dataaccess",db);
//            s.setAttribute("db",db);
            
            
            
             //COMPANY
            CompanyBean companybean = new CompanyBean();

            db= new DataAccess();
            db.openConnection();
            
            companybean.setDataAccess(db);

//            int cpid = companybean.existsCompany(company_name, db);
//
//            if (cpid == -1)
//            {
//                cpid = companybean.insertCompany(company_name, db);
//            }
//
//            companybean.setCpName(company_name);
//            companybean.setCpid(cpid);

            
            
            
            
            /*if (!studentbean.existsStudent(custid, artist_name, db)){
                likeartistbean.insertLikeArtist(custid, artist_name, db);
            }*/

            s.setAttribute("companybean", companybean );
            s.setAttribute("dataaccess",db);
            s.setAttribute("db",db);


            ///SESION
            s.setAttribute("key","000");
            s.setMaxInactiveInterval(1000);


            db.closeConsult();


            
            RequestDispatcher rd;
            if(request.getParameter("cmdRegister") != null){
                rd = this.getServletContext().getRequestDispatcher("/register_select.jsp");
                
            }else if(request.getParameter("cmdDisplay") != null){   
                rd = this.getServletContext().getRequestDispatcher("/enter_select.jsp");
                
                
            }else if(request.getParameter("cmdLogin_Student") != null){
                rd = this.getServletContext().getRequestDispatcher("/display_student.jsp");
                
            }else if(request.getParameter("cmdLogin_Company") != null){
                rd = this.getServletContext().getRequestDispatcher("/display_company.jsp");
                
            }else if(request.getParameter("cmdLogin_Moderator") != null){
                rd = this.getServletContext().getRequestDispatcher("/display_moderator.jsp");

            }else if(request.getParameter("cmdJob_Applied") != null){
        
                rd = this.getServletContext().getRequestDispatcher("/job_applied.jsp");
            }else if(request.getParameter("cmdStudent_Resume") != null){
        
                rd = this.getServletContext().getRequestDispatcher("/display_resume.jsp");
            }else if(request.getParameter("cmdResume_Result") != null){
        
                rd = this.getServletContext().getRequestDispatcher("/resume_review_result.jsp");
            }else if(request.getParameter("cmdUpvote") != null){
        
                rd = this.getServletContext().getRequestDispatcher("/upvote_resume.jsp");
            }else {
                rd = this.getServletContext().getRequestDispatcher("/error.jsp");
            }
            
            //RequestDispatcher rd = this.getServletContext().getRequestDispatcher("/menu.jsp");
            
            

                
            rd.forward(request,response);
            
            
 }

    public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException
    {
        processAction(request,response);
    }

    
    public void destroy()
    {       
        super.destroy();
    }
    
//    public static void main(String[] args){
//        ModeratorBean moderatorbean = new ModeratorBean();
//
//            dbtest= new DataAccess();
//            dbtest.openConnection();
//            
//            //moderatorbean.insertModerator("Anbo", "Wang", db);
//            //moderatorbean.setMFName("Anbo");
//            //moderatorbean.setMLName("Wang");
//
//            int mid = moderatorbean.existsModerator("Wang", dbtest);
//
//            if (mid == -1)
//            {
//                //mid = moderatorbean.insertModerator(moderator_fname, moderator_lname, db);
//                mid = moderatorbean.insertModerator("Anbo", "Wang", dbtest);
//            }
//
//            moderatorbean.setMLName("Wang");
//            moderatorbean.setMFName("Anbo");
//            moderatorbean.setMid(mid);
//            
//
//                
//                //logginModeratorTest = moderatorbean.getLogginModerator(1, dbtest);
//                System.out.println("list");
//                System.out.println(logginModeratorTest);
//            
//            
//                
//
//            //s.setAttribute("moderatorbean", moderatorbean );
//            //s.setAttribute("dataaccess", dbtest);
//            //s.setAttribute("db", dbtest);
//            
//        System.out.println("test");
//        System.out.println(mid);
//        System.out.println(login_mid_s2);
//        
//    
//    }
}