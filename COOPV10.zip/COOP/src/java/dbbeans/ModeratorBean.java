/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbbeans;

import connection.DataAccess;
import connection.Password;
import java.sql.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Scanner;

/**
 *
 * @author bomby
 */


public class ModeratorBean extends JFrame {
    
    private Connection connection;
    private Statement st;
    private ResultSet rs;
    private DataAccess dataaccess;
    private String moderatorList = "";
    private String[] logginModerator;

    
    
    private int mid;
    private String mfname;
    private String mlname;
    
    boolean loggedIn = false;
    private String mid_str = "";
    String lastName = "";
    String user = "";
    JTextField jtf1 = new JTextField(15);
    



public ModeratorBean()
{}

public void setDataAccess(DataAccess db)
    {
        dataaccess = db;
    }
    
    
    public void setMid(int value)
    {
        mid = value;
    }

    public int getMid()
    {
        return mid;
    }

    public void setMFName(String value)
    {
        mfname = value;
    }

    public String getMFName()
    {
        return mfname;
    }
    
    public void setMLName(String value)
    {
        mlname = value;
    }

    public String getMLName()
    {
        //return mlname;
        return lastName;
    }
 
   
    public int existsModerator(String id) {
        int tmpId = -1;
        String temp;
        
        connection = dataaccess.getConnection();

        try{
            st = connection.createStatement();
            rs  = st.executeQuery("SELECT * FROM coop.moderator");
            while (rs.next())
            {
                temp = rs.getString("mid");
                temp = temp.trim();
                if (temp.compareTo(id.trim())==0)
                    tmpId = Integer.parseInt(id);
            }
            rs.close();
            st.close();
            }catch(Exception e){
                System.out.println("Cant read from moderator table");
            }
            return tmpId;
    }

    public int insertModerator(String fname, String lname, DataAccess db)
    {
        connection = db.getConnection();
        int id = 0;        

        try {
            st = connection.createStatement();

            rs  = st.executeQuery("SELECT max(mid) as id FROM coop.moderator");
            rs.next();

            int max_id = rs.getInt(1);
            id = max_id + 1;

            System.out.println("ID: "+id);


            st.executeUpdate("INSERT INTO coop.moderator (mid, mfname , mlname) VALUES ("
                    +id+",'" + 
                    fname + "', '" + 
                    lname + "')");

            rs.close();
            st.close();
        }catch(Exception e){
            System.out.println("Cant insert into moderator table");
        }
        return id;
    }
    
    public String getModeratorList()
    {
        connection = dataaccess.getConnection();
        
        int mid;
        String mfname;
        String mlname;

        try {
            st = connection.createStatement();
            rs = st.executeQuery(
                    "SELECT mid, mfname, mlname FROM coop.moderator");
        } catch(Exception e){
            System.out.println("Cant read moderator table");
        }
        try{
            while (rs.next())
            {
    
                mid=rs.getInt("mid");
                mfname=rs.getString("mfname");
                mlname=rs.getString("mlname");
                moderatorList+="<tr><tr><td>"
                               + mid
                               + "</td><td>"
                               + mfname
                               + "</td><td>"
                               + mlname
                               +"</td></tr>";
            }
        }catch(Exception e){
            System.out.println("Error creating table "+e);
        }
        return moderatorList;
    }
    
    
    public String[] getLogginModerator(String id)
    {
       
        connection = dataaccess.getConnection();
        
  
        String mid;
        String mfname;
        String mlname;

        try {
            st = connection.createStatement();
            String sql = ("SELECT mid, mfname, mlname FROM coop.moderator WHERE mid =" +id);
            rs = st.executeQuery(sql);
            
           
                try{
                    while (rs.next())
                    {
                        mid=Integer.toString(rs.getInt("mid"));
                        mfname=rs.getString("mfname");
                        mlname=rs.getString("mlname");
                        logginModerator = new String[3];
                        logginModerator[0] = mid;
                        logginModerator[1] = mfname;
                        logginModerator[2] = mlname;
//                        logginModerator+="<tr><tr><td>"
//                                   + mid
//                                   + "</td><td>"
//                                   + mfname
//                                   + "</td><td>"
//                                   + mlname
//                                   +"</td></tr>";
                        
                    }
                }catch(Exception e){
                        System.out.println("Error creating table "+e);
                }
            
        }catch(NumberFormatException | SQLException e){
            System.out.println("Cant read moderator table");
        }
        
        return logginModerator;
    }
    
    
    
    
//    private void jButton1ActionPerformed(ActionEvent evt) {
//
//        user = jtf1.getText();
//        login();
//    }
    
    
    public boolean login(String id){
        
        connection = dataaccess.getConnection();
             
        try{
          PreparedStatement prep = connection.prepareStatement("SELECT mfname, mlname FROM coop.moderator where mid=" +id);  
          prep.setString(1,mid_str);
        
          ResultSet rs  = prep.executeQuery();
          if(rs.next())
          {
           lastName = rs.getString(1);
           loggedIn = true;
          }
          else
            loggedIn = false;
          prep.close();
          connection.close();
          
         }
        catch(Exception sqlex)
        {
          loggedIn = false;  
        }  
        
        return loggedIn;
   }
    
    public boolean isLoggedIn()
   {
     return loggedIn;
   }
   
   public void logOut()
   {
     loggedIn = false;
   }
    
    
    
    
    
    public static void main(String[] args){
        //System.out.println(logginModerator);
//        ModeratorBean test = new ModeratorBean();
//        
//        System.out.println(test.getModeratorList());
//        
//        try {
//            
//            Password password = new Password();
//
//            Class.forName("org.postgresql.Driver");
//            //Connection connection = DriverManager.getConnection("jdbc:postgresql://web0.site.uottawa.ca:15432/zwang143","zwang143","Wang1994");
//            Connection connection = DriverManager.getConnection("jdbc:postgresql://stampy.db.elephantsql.com:5432/fqcjjqzs", "fqcjjqzs", "Aq9AIVTxaJJJmQW6iAeiGNuxQsKP9GqL" );
//
//            int mid;
//            String mfname;
//            String mlname;
//            
//            Statement st = connection.createStatement();
//            String moderatorList="";
//            
//            ResultSet rs = st.executeQuery("SELECT mid, mfname, mlname  FROM coop.moderator");
//        
//            while (rs.next())
//            {
//                mid = rs.getInt("mid");
//                mfname = rs.getString("mfname");
//                mlname = rs.getString("mlname");
//                moderatorList+="<tr><tr><td>"
//                               + mid
//                               + "</td><td>"
//                               + mfname
//                               + "</td><td>"
//                               + mlname
//                               +"</td></tr>";
//            } 
//            
//            System.out.println(moderatorList);
//            
//        }catch(Exception e){
//            System.out.println("Error creating table "+e);
//        }
   }
}