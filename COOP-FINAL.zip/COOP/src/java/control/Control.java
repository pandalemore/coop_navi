
package control;

import dbbeans.*;
import connection.DataAccess;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;




public class Control extends HttpServlet
{
    private DataAccess db;
    
    public static DataAccess dbtest;
    private static String studentJobList = "";
    //private static String logginModeratorTest = "";
    //private String logginModerator = "argh";
    
    //static String login_mid_s2;
    //static int login_mid;
    static String login_sid;
    //private boolean loggedin = false;
    //private static CompanyBean companybean2;


    
    private void processAction(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException
    {
            HttpSession s = request.getSession(true);
   
            
            String student_name = (String)request.getParameter("txtLname");
            
            String moderator_lname = (String)request.getParameter("txtMlname");
            String moderator_fname = (String)request.getParameter("txtMfname");
            
            //String login_mid_s = (String)request.getParameter("login_mid");
            //login_mid_s2 = login_mid_s;
            //int login_mid = Integer.valueOf(login_mid_s);
            
            
            String login_sid = (String)request.getParameter("login_sid");
            String company_name = (String)request.getParameter("txtCpname");


            


            //STUDENT
            StudentBean studentbean = new StudentBean();

            db= new DataAccess();
            db.openConnection();
            
            studentbean.setDataAccess(db);

//            int sid = studentbean.existsStudent(student_name, db);
//
//            if (sid == -1)
//            {
//                sid = studentbean.insertStudent(student_name, db);
//            }
//
//            studentbean.setlName(student_name);
//            studentbean.setSid(sid);
//
//            s.setAttribute("studentbean", studentbean );
            
            
            /*if (!studentbean.existsStudent(custid, artist_name, db)){
                likeartistbean.insertLikeArtist(custid, artist_name, db);
            }*/

            
            
            s.setAttribute("studentbean", studentbean );
            s.setAttribute("dataaccess",db);
            s.setAttribute("db",db);
            
            


            //MODERATOR
            ModeratorBean moderatorbean = new ModeratorBean();
            
            db= new DataAccess();
            db.openConnection();
            
            moderatorbean.setDataAccess(db);

            s.setAttribute("moderatorbean", moderatorbean );
            s.setAttribute("dataaccess", db);
            s.setAttribute("db", db);

            
            //COMPANY
            
            
            
            //if(loggedin==false){
             
            CompanyBean companybean = new CompanyBean();
                
                //companybean = new CompanyBean();
            //}

            db= new DataAccess();
            db.openConnection();
            
            companybean.setDataAccess(db);


            s.setAttribute("companybean", companybean );
            s.setAttribute("dataaccess",db);
            s.setAttribute("db",db);
            
            
            //JOB
            JobBean jobbean = new JobBean();

            db= new DataAccess();
            db.openConnection();
            
            jobbean.setDataAccess(db);
            
            s.setAttribute("jobbean", jobbean );
            s.setAttribute("dataaccess",db);
            s.setAttribute("db",db);
            
            //JOB APPLIED
            JobAppliedBean jabean = new JobAppliedBean();

            db= new DataAccess();
            db.openConnection();
            
            jabean.setDataAccess(db);
            
            s.setAttribute("jabean", jabean );
            s.setAttribute("dataaccess",db);
            s.setAttribute("db",db);
            
            //RESUME
            ResumeBean resumebean = new ResumeBean();
            db= new DataAccess();
            db.openConnection();
            
            resumebean.setDataAccess(db);
           
            s.setAttribute("resumebean", resumebean );
            s.setAttribute("dataaccess",db);
            s.setAttribute("db",db);
            
            //RESUME_REVIEW
            ResumeReviewBean resumereviewbean = new ResumeReviewBean();
            db= new DataAccess();
            db.openConnection();
            
            resumereviewbean.setDataAccess(db);
            
            s.setAttribute("resumereviewbean", resumereviewbean );
            s.setAttribute("dataaccess",db);
            s.setAttribute("db",db);





            ///SESION
            s.setAttribute("key","000");
            s.setMaxInactiveInterval(1000);


            //loggedin = true;
            db.closeConsult();


            
            RequestDispatcher rd;
            if(request.getParameter("cmdRegister") != null){
                rd = this.getServletContext().getRequestDispatcher("/register_select.jsp");
                
            }else if(request.getParameter("cmdDisplay") != null){   
                rd = this.getServletContext().getRequestDispatcher("/enter_select.jsp");
   
            }else if(request.getParameter("cmdLogin_Student") != null){
                rd = this.getServletContext().getRequestDispatcher("/display_student.jsp");
                
            }else if(request.getParameter("cmdLogin_Company") != null){
                rd = this.getServletContext().getRequestDispatcher("/display_company.jsp");
                
            }else if(request.getParameter("cmdLogin_Moderator") != null){
                rd = this.getServletContext().getRequestDispatcher("/display_moderator.jsp");
                
            }else {
                rd = this.getServletContext().getRequestDispatcher("/error.jsp");
            }
            
            //RequestDispatcher rd = this.getServletContext().getRequestDispatcher("/menu.jsp");
            
            

                
            rd.forward(request,response);
            
            
 }

    public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException
    {
        processAction(request,response);
    }

    
    public void destroy()
    {       
        super.destroy();
    }
    
//    public static void main(String[] args){
//        //ModeratorBean moderatorbean = new ModeratorBean();
//        JobBean jobbean = new JobBean();
//        StudentBean studentbean = new StudentBean();
//        studentbean.setSid(1234567);
//
//            dbtest= new DataAccess();
//            dbtest.openConnection();
//            jobbean.setDataAccess(dbtest);
//            
//            //String sid = (String)(request.getParameter("login_sid"));
//            System.out.println("3343");
//            String sid = Integer.toString(studentbean.getSid());
//                //out.println(sid);
//                System.out.println(jobbean.getStudentJobList(sid));
//            
//            
//            
//            
//            //moderatorbean.insertModerator("Anbo", "Wang", db);
//            //moderatorbean.setMFName("Anbo");
//            //moderatorbean.setMLName("Wang");
//
////            int mid = moderatorbean.existsModerator("Wang", dbtest);
////
////            if (mid == -1)
////            {
////                //mid = moderatorbean.insertModerator(moderator_fname, moderator_lname, db);
////                mid = moderatorbean.insertModerator("Anbo", "Wang", dbtest);
////            }
////
////            moderatorbean.setMLName("Wang");
////            moderatorbean.setMFName("Anbo");
////            moderatorbean.setMid(mid);
////            
////
////                
////                //logginModeratorTest = moderatorbean.getLogginModerator(1, dbtest);
////                System.out.println("list");
////                System.out.println(logginModeratorTest);
////            
////            
////                
////
////            //s.setAttribute("moderatorbean", moderatorbean );
////            //s.setAttribute("dataaccess", dbtest);
////            //s.setAttribute("db", dbtest);
////            
////        System.out.println("test");
////        System.out.println(mid);
////        System.out.println(login_mid_s2);
//        
//    
//    }
}