/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

import dbbeans.*;
import connection.DataAccess;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

/**
 *
 * @author bomby
 */
public class ControlAll extends HttpServlet {
    
     private void processAction(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException
    {
            //HttpSession s = request.getSession(true);
            
            RequestDispatcher rd;
 
            
            
            if(request.getParameter("saveM") != null){
                rd = this.getServletContext().getRequestDispatcher("/index.jsp");
            }else if(request.getParameter("saveC") != null){
                rd = this.getServletContext().getRequestDispatcher("/index.jsp");
                
            }else if(request.getParameter("saveS") != null){
                rd = this.getServletContext().getRequestDispatcher("/index.jsp");
          
            }else if(request.getParameter("addJ") != null){
                //rd = this.getServletContext().getRequestDispatcher("/display_company.jsp");
                rd = this.getServletContext().getRequestDispatcher("/display_company_afterlogin.jsp");
            
            }else if(request.getParameter("saveResume") != null){
                //rd = this.getServletContext().getRequestDispatcher("/display_company.jsp");
                rd = this.getServletContext().getRequestDispatcher("/display_student_afterlogin.jsp");
                
                
            }else if(request.getParameter("cmdCompanyJA") != null){
                rd = this.getServletContext().getRequestDispatcher("/display_company_ja.jsp");
                
            }else if(request.getParameter("cmdStudent_Resume") != null){
                rd = this.getServletContext().getRequestDispatcher("/display_resume.jsp");
            }else if(request.getParameter("cmdApplyJob") != null){
                rd = this.getServletContext().getRequestDispatcher("/display_student_ja.jsp");
            }else if(request.getParameter("cmdLogin_reviewid") != null){
                rd = this.getServletContext().getRequestDispatcher("/display_resume_review.jsp");
            }else if(request.getParameter("cmdLogin_reviewid_update") != null){
                rd = this.getServletContext().getRequestDispatcher("/update_resume_review.jsp");
            
            }else if(request.getParameter("cmdUpdateComment") != null){
                rd = this.getServletContext().getRequestDispatcher("/display_resume_review_m.jsp");
            }else if(request.getParameter("upload_upvote") != null){
                rd = this.getServletContext().getRequestDispatcher("/display_resume_review_afterlogin.jsp");
            }else if(request.getParameter("cmdResumeDetails") != null){
                rd = this.getServletContext().getRequestDispatcher("/display_company_resume_details.jsp");
            }else if(request.getParameter("cmdAN") != null){
                rd = this.getServletContext().getRequestDispatcher("/display_company_afterlogin.jsp");
            }else {
                rd = this.getServletContext().getRequestDispatcher("/error.jsp");
            }
            
            //RequestDispatcher rd = this.getServletContext().getRequestDispatcher("/menu.jsp");
            
            

                
            rd.forward(request,response);
            
            
 }

    public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException
    {
        processAction(request,response);
    }

    
    public void destroy()
    {       
        super.destroy();
    }
    
    
}
