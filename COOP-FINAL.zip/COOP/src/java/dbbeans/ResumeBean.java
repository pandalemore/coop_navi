/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbbeans;

/**
 *
 * @author Panda
 */
import connection.DataAccess;
import java.sql.*;

public class ResumeBean {

    
    private Connection connection;
    private Statement st;
    private ResultSet rs;
    private DataAccess dataaccess;
    private String resumeList;
    private String resumeForCompany;
    private String resume;

    
    private int sid;
    private int rid;
    private int rversion;
    private int mid;
    private String content;
    
    public void setDataAccess(DataAccess db)
    {
        dataaccess = db;
    }
    
        /**
     * @return the sid
     */
    public int getSid() {
        return sid;
    }

    /**
     * @param sid the sid to set
     */
    public void setSid(int sid) {
        this.sid = sid;
    }

    /**
     * @return the rid
     */
    public int getRid() {
        return rid;
    }

    /**
     * @param rid the rid to set
     */
    public void setRid(int rid) {
        this.rid = rid;
    }

    /**
     * @return the rversion
     */
    public int getrversion() {
        return rversion;
    }

    /**
     * @param rversion the rversion to set
     */
    public void setrversion(int rversion) {
        this.rversion = rversion;
    }

    /**
     * @return the mid
     */
    public int getMid() {
        return mid;
    }

    /**
     * @param mid the mid to set
     */
    public void setMid(int mid) {
        this.mid = mid;
    }

    /**
     * @return the content
     */
    public String getContent() {
        return content;
    }

    /**
     * @param content the content to set
     */
    public void setContent(String content) {
        this.content = content;
    }
    

    
    public int existsResume(String id){
    int tmpId = -1;
        String temp;
        
        connection = dataaccess.getConnection();
        try{
            st = connection.createStatement();
            rs  = st.executeQuery("SELECT * FROM coop.resume");
            while (rs.next())
            {
                temp = rs.getString("rid");
                temp = temp.trim();
                if (temp.compareTo(id.trim())==0)
                    tmpId = Integer.parseInt(id);
            }
            rs.close();
            st.close();
            }catch(Exception e){
                System.out.println("Cant read from resume table");
            }
            return tmpId;
    }
    
    public String getResume(String id){
        connection = dataaccess.getConnection();
        resumeList = "";
        
        String sid;
        String rid;
        String rversion;
        String mid;
        //String content;
        
        try {
            st = connection.createStatement();
            String sql = ("SELECT DISTINCT R.rid, R.rversion, R.sid, R.mid FROM coop.resume AS R, coop.student as S WHERE R.sid =" +id);
            rs = st.executeQuery(sql);
            
           
                try{
                    while (rs.next())
                    {
                        rid = Integer.toString(rs.getInt("rid"));
                        rversion = Integer.toString(rs.getInt("rversion"));
                        sid = Integer.toString(rs.getInt("sid"));
                        mid = Integer.toString(rs.getInt("mid"));
                        //content = rs.getString("content");
             
            
                        

                        resumeList+="<tr><tr><td>"
                                       + rid
                                       + "</td><td>"
                                       + rversion
                                       + "</td><td>"
                                       + sid
                                       + "</td><td>"
                                       + mid
                                       //+ "</td><td>"
                                       //+ content
                                       +"</td></tr>";

            
             
                    
                    }
                }catch(Exception e){
                        System.out.println("Error creating table "+e);
                }
            
        }catch(NumberFormatException | SQLException e){
            System.out.println("Cant read resume table");
        }
        
        return resumeList;
    }
    
    public String getResumeForCompany(String id){
        connection = dataaccess.getConnection();
        resumeForCompany = "";
        
        String sid;
        String email;
        String lname;
        String fname;
        String scname;
        String year;
        String major;
        String content;
        
        try {
            st = connection.createStatement();
            String sql = ("SELECT R.sid, S.email, S.lname, S.fname, SC.scname, S.year, S.major, R.content FROM coop.resume AS R, coop.student as S, coop.school AS SC WHERE S.scid = SC.scid AND R.sid =" +id);
            rs = st.executeQuery(sql);
            
           
                try{
                    while (rs.next())
                    {
                        sid = Integer.toString(rs.getInt("sid"));
                        email = rs.getString("email");
                        lname = rs.getString("lname");
                        fname = rs.getString("fname");
                        scname = rs.getString("scname");
                        year = Integer.toString(rs.getInt("year"));
                        major = rs.getString("major");
                        content = rs.getString("content");
             
            
                        

                        resumeList+="<tr><tr><td>"
                                       + sid
                                       + "</td><td>"
                                       + email
                                       + "</td><td>"
                                       + lname
                                       + "</td><td>"
                                       + fname
                                       + "</td><td>"
                                       + scname
                                       + "</td><td>"
                                       + year
                                       + "</td><td>"
                                       + major
                                       + "</td><td>"
                                       + content
                                       +"</td></tr>";

            
             
                    
                    }
                }catch(Exception e){
                        System.out.println("Error creating table "+e);
                }
            
        }catch(NumberFormatException | SQLException e){
            System.out.println("Cant read resume table");
        }
        
        return resumeList;
    }
    
        public String getResumeByMid(String id){
        connection = dataaccess.getConnection();
        resume = "";
        
        String sid;
        String rid;
        String rversion;
        String mid;
        //String content;
        
        try {
            st = connection.createStatement();
            String sql = ("SELECT R.rid, R.rversion, R.sid, R.mid FROM coop.resume AS R, coop.moderator as M WHERE M.mid =" +id);
            rs = st.executeQuery(sql);
            
           
                try{
                    while (rs.next())
                    {
                        rid = Integer.toString(rs.getInt("rid"));
                        rversion = Integer.toString(rs.getInt("rversion"));
                        sid = Integer.toString(rs.getInt("sid"));
                        mid = Integer.toString(rs.getInt("mid"));
                        //content = rs.getString("content");
             

                        
                        resume+="<tr><tr><td>"
                                       + rid
                                       + "</td><td>"
                                       + rversion
                                       + "</td><td>"
                                       + sid
                                       + "</td><td>"
                                       + mid
                                       //+ "</td><td>"
                                       //+ content
                                       +"</td></tr>";
             
                    
                    }
                }catch(Exception e){
                        System.out.println("Error creating table "+e);
                }
            
        }catch(NumberFormatException | SQLException e){
            System.out.println("Cant read resume table");
        }
        
        return  resume;
    }
    
        public int insertResume(String sid, String content)
    {
        connection = dataaccess.getConnection();
        int id = 0;        

        try {
            st = connection.createStatement();

            rs  = st.executeQuery("SELECT max(rid) as id FROM coop.resume");
            rs.next();

            int max_id = rs.getInt(1);
            id = max_id + 1;

            System.out.println("ID: "+id);


            st.executeUpdate("INSERT INTO coop.resume (rid, rversion , sid, mid, content) VALUES ("
                    +id+", 1 ," + 
                    sid + ", 123, '" +
                    content + "')");
            
            ResumeReviewBean rvb = new ResumeReviewBean();
            rvb.setDataAccess(dataaccess);
            rvb.insertResumeReview(Integer.toString(id));
            

            rs.close();
            st.close();
        }catch(Exception e){
            System.out.println("Cant insert into resume table");
        }
        return id;
    }
}
