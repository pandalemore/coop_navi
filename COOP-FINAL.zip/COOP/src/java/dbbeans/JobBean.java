/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbbeans;

/**
 *
 * @author bomby
 */
import connection.DataAccess;
import java.sql.*;

/**
 *
 * @author Panda
 */
public class JobBean {
    
    private Connection connection;
    private Statement st;
    private ResultSet rs;
    private DataAccess dataaccess;
    private String jobList;
    private String studentJobList;
    private String companyJList;
    //private String[] loginStudent;
    
    
    private int jid;
    private int cpid;
    private String jname;
    private String jlevel;
    private String jdesp;
    private String category;
    private int numpos;
    //private int jrating;

    
    
    
    
    public JobBean() {
    }
    
    public void setDataAccess(DataAccess db)
    {
        dataaccess = db;
    }
    
    
    public void setJid(int value)
    {
        jid = value;
    }

    public int getJid()
    {
        return jid;
    }
    
    public void setCpid(int value)
    {
        cpid = value;
    }

    public int getCpid()
    {
        return cpid;
    }
    
    public void setJlevel(String value)
    {
        jlevel = value;
    }

    public String getJlevel()
    {
        return jlevel;
    }
    public void setNumpos(int value)
    {
        numpos = value;
    }

    public int getNumpos()
    {
        return numpos;
    }
    
//    public void setJrating(int value)
//    {
//        jrating = value;
//    }
//
//    public int getJrating()
//    {
//        return jrating;
//    }

    public void setJname(String value)
    {
        jname = value;
    }

    public String getJname()
    {
        return jname;
    }
    
    public void setJdesp(String value)
    {
        jdesp = value;
    }

    public String getJdesp()
    {
        return jdesp;
    }
    
    public void setCategory(String value)
    {
        category = value;
    }

    public String getCategory()
    {
        return category;
    }
    
    

   
    public int existsJob(String id) {
        int tmpId = -1;
        String temp;
        
        connection = dataaccess.getConnection();

        try{
            st = connection.createStatement();
            rs  = st.executeQuery("SELECT * FROM coop.job");
            while (rs.next())
            {
                temp = rs.getString("jid");
                temp = temp.trim();
                if (temp.compareTo(id.trim())==0)
                    tmpId = Integer.parseInt(id);
            }
            rs.close();
            st.close();
            }catch(Exception e){
                System.out.println("Cant read from job table");
            }
            return tmpId;
    }
    
    public String findCpid(String jid){
        connection = dataaccess.getConnection();
        String cpid = "";
        
        try{
            st = connection.createStatement();
            rs = st.executeQuery("SELECT cpid FROM coop.job WHERE jid =" +jid);
            while (rs.next())
            {
                cpid = rs.getString("cpid");
            }
            rs.close();
            st.close();
            }catch(Exception e){
                System.out.println("Cant read from job table");
            }
            return cpid;
        
    }

    public int insertJob(String cpid, String jname, String jlevel, String jdesp, String category, String numpos)
    {
        connection = dataaccess.getConnection();
        int id = 0;        

        try {
            st = connection.createStatement();

            rs  = st.executeQuery("SELECT max(jid) as id FROM coop.job");
            rs.next();

            int max_id = rs.getInt(1);
            id = max_id + 1;

            System.out.println("ID: "+id);

            st.executeUpdate("INSERT INTO coop.job "
                            + " (jid, cpid , jname, jlevel, jdesp, category, numpos) "
                    + "VALUES ("+
                    id+"," + 
                    cpid+ ",'" + 
                    jname + "','" + 
                    jlevel + "','" + 
                    jdesp + "','" + 
                    category + "'," + 
                    numpos + ")");

            rs.close();
            st.close();
        }catch(Exception e){
            System.out.println("Cant insert into job table");
        }
        return id;
    }
    
    public String getJobList()
    {
        connection = dataaccess.getConnection();
        jobList = "";
        
        int jid;
        int cpid;
        String jname;
        int jlevel;
        String jdesp;
        String category;
        int numpos;

        try {
            st = connection.createStatement();
            rs = st.executeQuery(
                    "SELECT * FROM coop.job");
        } catch(Exception e){
            System.out.println("Cant read job table");
        }
        try{
            while (rs.next())
            {
                jid = rs.getInt("jid");
                cpid = rs.getInt("jid");
                jname = rs.getString("jname");
                jlevel = rs.getInt("jlevel");
                jdesp = rs.getString("jdesp");
                category = rs.getString("category");
                numpos = rs.getInt("numpos");
 
                
                jobList+="<tr><tr><td>"
                               + jid
                               + "</td><td>"
                               + cpid
                               + "</td><td>"
                               + jname
                               + "</td><td>"
                               + jlevel
                               + "</td><td>"
                               + jdesp
                               + "</td><td>"
                               + category
                               + "</td><td>"
                               + numpos
                               +"</td></tr>";
            }
        }catch(Exception e){
            System.out.println("Error creating table "+e);
        }
        return jobList;
    }
    
    public String getStudentJobList(String sid)
    {
        connection = dataaccess.getConnection();
        studentJobList = "";
        
        int jid;
        String cpname;
        String jname;
        String jlevel;
        int numpos;
        String jdesp;
    
        

        try {
            st = connection.createStatement();
            rs = st.executeQuery(
                    "SELECT J.jid, C.cpname, J.jname, J.jlevel, J.numpos, J.jdesp FROM coop.student AS S, coop.job AS J, coop.company AS C WHERE J.cpid = C.cpid AND J.category = S.major AND S.sid =" +sid);
        } catch(Exception e){
            System.out.println("Cant read from Student/Job/Company tables");
        }
 
        try{
            while (rs.next())
            {
                jid = rs.getInt("jid");
                cpname = rs.getString("cpname");
                jname = rs.getString("jname");
                jlevel = rs.getString("jlevel");
                numpos = rs.getInt("numpos");
                jdesp = rs.getString("jdesp");
        
 
                
                studentJobList+="<tr><tr><td>"
//                               + "<p><input <c:out type=\"${radio}\"/>"
//                               + "<c:out name=\"${rdJobApply}\"/>" 
//                               + "<c:out value=\"${Apply}\"/>"
//                               + "></p>"
//                               + "</td><td>"
                               + jid
                               + "</td><td>"
                               + cpname
                               + "</td><td>"
                               + jname
                               + "</td><td>"
                               + jlevel
                               + "</td><td>"
                               + numpos
                               + "</td><td>"
                               + jdesp
                               +"</td></tr>";
            }
        }catch(Exception e){
            System.out.println("Error creating student job list "+e);
        }
        return studentJobList;
    }
    
    public String getCompanyJList(String cpid)
    {
        connection = dataaccess.getConnection();
        companyJList = "";
        
     
        int jid;
        String jname;
        int numpos;
      
    
        

        try {
            st = connection.createStatement();
            rs = st.executeQuery(
                    "SELECT J.jid, J.jname, J.numpos " +
                    "FROM coop.job AS J, coop.company AS C " +
                    "WHERE C.cpid =" +cpid);
        } catch(Exception e){
            System.out.println("Cant read from Job/Company tables");
        }
 
        try{
            while (rs.next())
            {
                
                jid = rs.getInt("jid");
                jname = rs.getString("jname");
                numpos = rs.getInt("numpos");
            
            
        
 
                
                companyJList+="<tr><tr><td>"
                               + jid
                               + "</td><td>"
                               + jname
                               + "</td><td>"
                               + numpos
                               +"</td></tr>";
            }
        }catch(Exception e){
            System.out.println("Error creating company job list "+e);
        }
        if(rs == null){
            companyJList = "<tr><tr><td>No jobs posted!</td></tr>";
        }
        return companyJList;
    }
    

    
    
    
    
    
    
    
}
