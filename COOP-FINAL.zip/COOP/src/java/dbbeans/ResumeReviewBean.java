/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbbeans;

/**
 *
 * @author Panda
 */
import connection.DataAccess;
import java.sql.*;

public class ResumeReviewBean {

    
    private Connection connection;
    private Statement st;
    private ResultSet rs;
    private DataAccess dataaccess;
    private String[] resumeReview;
    
    private int reviewid;
    private int rid;
    private String comment;
    private int mid;
    private String upvote;
    
    public void setDataAccess(DataAccess db)
    {
        dataaccess = db;
    }
    
    /**
     * @return the reviewid
     */
    public int getReviewid() {
        return reviewid;
    }

    /**
     * @param reviewid the reviewid to set
     */
    public void setReviewid(int reviewid) {
        this.reviewid = reviewid;
    }

    /**
     * @return the rid
     */
    public int getRid() {
        return rid;
    }

    /**
     * @param rid the rid to set
     */
    public void setRid(int rid) {
        this.rid = rid;
    }

    /**
     * @return the comment
     */
    public String getComment() {
        return comment;
    }

    /**
     * @param comment the comment to set
     */
    public void setComment(String comment) {
        this.comment = comment;
    }
    
    /**
     * @return the upvote
     */
    public String getUpvote() {
        return upvote;
    }

    /**
     * @param upvote the upvote to set
     */
    public void setUpvote(String upvote) {
        this.upvote = upvote;
    }

    /**
     * @return the mid
     */
    public int getMid() {
        return mid;
    }

    /**
     * @param mid the mid to set
     */
    public void setMid(int mid) {
        this.mid = mid;
    }
    
    public int existsResumeReview(String id){
        int tmpId = -1;
        String temp;
        
        connection = dataaccess.getConnection();
        try{
            st = connection.createStatement();
            rs  = st.executeQuery("SELECT * FROM coop.resume_review");
            while (rs.next())
            {
                temp = rs.getString("reviewid");
                temp = temp.trim();
                if (temp.compareTo(id.trim())==0)
                    tmpId = Integer.parseInt(id);
            }
            rs.close();
            st.close();
            }catch(Exception e){
                System.out.println("Cant read from resume review table");
            }
            return tmpId;
    }
    
        public String[] getResumeReview(String id){
        connection = dataaccess.getConnection();
        String reviewid;
        String rid;
        String comment;
        String mid;
        String upvote;
        
        try {
            st = connection.createStatement();
            String sql = ("SELECT reviewid, rid, comment, mid, upvote FROM coop.resume_review  WHERE reviewid =" +id);
            rs = st.executeQuery(sql);
            
           
                try{
                    while (rs.next())
                    {
                        reviewid = Integer.toString(rs.getInt("reviewid"));
                        rid = Integer.toString(rs.getInt("rid"));
                        mid = Integer.toString(rs.getInt("mid"));
                        comment = rs.getString("comment");
                        upvote = rs.getString("upvote");
             
            


                        resumeReview = new String[5];
                        resumeReview[0] = reviewid;
                        resumeReview[1] = rid;
                        resumeReview[2] = mid;
                        resumeReview[3] = comment;
                        resumeReview[4] = upvote;
             
                    
                    }
                }catch(Exception e){
                        System.out.println("Error creating table "+e);
                }
            
        }catch(NumberFormatException | SQLException e){
            System.out.println("Cant read resume review table");
        }
        
        return  resumeReview;
        }
        
       
        public void updateComment(String rvid, String comment){
            //boolean updated = false;

            connection = dataaccess.getConnection();



             try {
                 st = connection.createStatement();
                 String sql = ("UPDATE coop.resume_review SET comment = '" +comment+
                         "' WHERE reviewid ="+rvid);
                 rs = st.executeQuery(sql);
                 //updated = true;
             } catch(Exception e){
                 System.out.println("Cant read resume review table");
                 //updated = false;
             }

            //return updated;
        }
        
        public String getResumeContent(String rvid){
            
            connection = dataaccess.getConnection();
            String rContent = "";



             try {
                 st = connection.createStatement();
                 String sql = ("SELECT R.content "  
                         + "FROM coop.resume_review AS RV, coop.resume AS R "
                         + "WHERE R.rid = RV.rid AND RV.reviewid ="+rvid);
                 rs = st.executeQuery(sql);
                 
                  try{
                    while (rs.next())
                    {
                        
                        rContent = rs.getString("content");
                    }
                    }catch(SQLException e){
                        System.out.println("Error creating content "+e);
                    }
                 
                
             } catch(SQLException e){
                 System.out.println("Cant read resume review/resume table");
        
             }
             
              
             return rContent;
            
        }
    
    
    public int insertResumeReview(String rid)
    {
        connection = dataaccess.getConnection();
        int id = 0;        

        try {
            st = connection.createStatement();

            rs  = st.executeQuery("SELECT max(reviewid) as id FROM coop.resume_review");
            rs.next();

            int max_id = rs.getInt(1);
            id = max_id + 1;

            System.out.println("ID: "+id);
            
       

            st.executeUpdate("INSERT INTO coop.resume_review (reviewid, rid, comment, mid, upvote) VALUES ("
                    +id+", "
                    +rid+ ", NULL, 123, NULL)");

            rs.close();
            st.close();
        }catch(Exception e){
            System.out.println("Cant insert into resume review table");
        }
        return id;
    }
    
    public void updateUpvote(String rvid, String upvote){
            //boolean updated = false;

            connection = dataaccess.getConnection();



             try {
                 st = connection.createStatement();
                 String sql = ("UPDATE coop.resume_review SET upvote = '" +upvote+
                         "' WHERE reviewid ="+rvid);
                 rs = st.executeQuery(sql);
                 //updated = true;
             } catch(Exception e){
                 System.out.println("Cant read resume review table");
                 //updated = false;
             }

            //return updated;
        }
    
    
}
