/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbbeans;

/**
 *
 * @author bomby
 */
import connection.DataAccess;
import java.sql.*;

/**
 *
 * @author Panda
 */
public class JobAppliedBean {
    
    private Connection connection;
    private Statement st;
    private ResultSet rs;
    private DataAccess dataaccess;
    private String jobAppliedList;
    private String studentJAList;
    
    private String companyJASList;
    //private String[] loginStudent;
    
    
    private int jaid;
    private int sid;
    private int jid;
    private int cpid;


    
    
    
    
    public JobAppliedBean() {
    }
    
    public void setDataAccess(DataAccess db)
    {
        dataaccess = db;
    }
    
    
    public void setJaid(int value)
    {
        jaid = value;
    }

    public int getJaid()
    {
        return jaid;
    }
    
    public void setCpid(int value)
    {
        cpid = value;
    }

    public int getCpid()
    {
        return cpid;
    }
    
    public void setSid(int value)
    {
        sid = value;
    }

    public int getSid()
    {
        return sid;
    }
    
    public void setJid(int value)
    {
        jid = value;
    }

    public int getJid()
    {
        return jid;
    }
    

   
    public int existsJA(String id) {
        int tmpId = -1;
        String temp;
        
        connection = dataaccess.getConnection();

        try{
            st = connection.createStatement();
            rs  = st.executeQuery("SELECT * FROM coop.job_applied");
            while (rs.next())
            {
                temp = rs.getString("jaid");
                temp = temp.trim();
                if (temp.compareTo(id.trim())==0)
                    tmpId = Integer.parseInt(id);
            }
            rs.close();
            st.close();
            }catch(Exception e){
                System.out.println("Cant read from job_applied table");
            }
            return tmpId;
    }

    public int insertJA(String sid, String jid, String cpid)
    {
        connection = dataaccess.getConnection();
        int id = 0;        

        try {
            st = connection.createStatement();

            rs  = st.executeQuery("SELECT max(jaid) as id FROM coop.job_applied");
            rs.next();

            int max_id = rs.getInt(1);
            id = max_id + 1;

            System.out.println("ID: "+id);

            st.executeUpdate("INSERT INTO coop.job_applied "
                            + " (jaid, sid, jid, cpid, hired) "+ 
                    "VALUES (" + 
                    id+"," + 
                    sid+ "," + 
                    jid + "," + 
                    cpid + ", false)");

            rs.close();
            st.close();
        }catch(Exception e){
            System.out.println("Cant insert into job_applied table");
        }
        return id;
    }
    
    public String getJAList()
    {
        connection = dataaccess.getConnection();
        jobAppliedList = "";
        
        int jaid;
        int sid;
        int jid;
        int cpid;

        try {
            st = connection.createStatement();
            rs = st.executeQuery(
                    "SELECT * FROM coop.job_applied");
        } catch(Exception e){
            System.out.println("Cant read job_applied table");
        }
        try{
            while (rs.next())
            {
                jaid = rs.getInt("jaid");
                sid = rs.getInt("sid");
                jid = rs.getInt("jid");
                cpid = rs.getInt("cpid");
           
                
 
                
                jobAppliedList+="<tr><tr><td>"
                               + jaid
                               + "</td><td>"
                               + sid
                               + "</td><td>"
                               + jid
                               + "</td><td>"
                               + cpid
                               +"</td></tr>";
            }
        }catch(Exception e){
            System.out.println("Error creating table "+e);
        }
        return jobAppliedList;
    }
    
    public String getStudentJAList(String sid)
    {
        connection = dataaccess.getConnection();
        studentJAList = "";
        
        int jaid;
        int jid;
        String cpname;
        String jname;

    
        

        try {
            st = connection.createStatement();
            rs = st.executeQuery(
                    "SELECT JA.jaid, JA.jid, C.cpname, J.jname " +
                    "FROM coop.job AS J, coop.company AS C, coop.student AS S, coop.job_applied AS JA " +
                    "WHERE JA.jid = J.jid AND JA.cpid = C.cpid AND JA.sid = S.sid AND S.sid =" +sid);
        } catch(Exception e){
            System.out.println("Cant read from Student/Job/Company tables");
        }
 
        try{
            while (rs.next())
            {
                jaid = rs.getInt("jaid");
                jid = rs.getInt("jid");
                cpname = rs.getString("cpname");
                jname = rs.getString("jname");
            
        
 
                
                studentJAList+="<tr><tr><td>"
                               + jaid
                               + "</td><td>"
                               + jid
                               + "</td><td>"
                               + cpname
                               + "</td><td>"
                               + jname
                               +"</td></tr>";
            }
        }catch(Exception e){
            System.out.println("Error creating student job_applied list "+e);
        }
        return studentJAList;
    }
    
    public String getCompanyJASList(String cpid, String jid_str)
    {
        connection = dataaccess.getConnection();
        companyJASList = "";
        
        int jaid;
        int jid;
        String jname;
        int sid;
        String email;
        String lname;
        String fname;
        String year;
        String major;
        String content;
        String hired;

    
        

        try {
            st = connection.createStatement();
            rs = st.executeQuery(
                    "SELECT DISTINCT JA.jaid, S.sid, S.email, S.lname, S.fname, S.year, S.major, R.content, JA.hired " +
                    "FROM coop.job AS J, coop.company AS C, coop.student AS S, coop.job_applied AS JA, coop.resume AS R " +
                    "WHERE S.sid = R.sid AND JA.sid = S.sid AND JA.cpid = C.cpid  AND C.cpid =" +cpid+
                    "AND JA.jid =" +jid_str+
                    "AND R.rid = (SELECT MAX(rid) FROM coop.resume)");
        } catch(Exception e){
            System.out.println("Cant read from Student/Job/Company tables");
        }
 
        try{
            while (rs.next())
            {
                jaid = rs.getInt("jaid");
                //jid = rs.getInt("jid");
                //jname = rs.getString("jname");
                sid = rs.getInt("sid");
                email = rs.getString("email");
                lname = rs.getString("lname");
                fname = rs.getString("fname");
                year = rs.getString("year");
                major = rs.getString("major");
                content = rs.getString("content");
                hired = rs.getString("hired");
            
        
 
                
                companyJASList+="<tr><tr><td>"
                               + jaid
                               + "</td><td>"
//                               + jid
//                               + "</td><td>"
//                               + jname
//                               + "</td><td>"
                               + sid
                               + "</td><td>"
                               + email
                               + "</td><td>"
                               + lname
                               + "</td><td>"
                               + fname
                               + "</td><td>"
                               + year
                               + "</td><td>"
                               + major
                               + "</td><td>"
                               + content
                               + "</td><td>"
                               + hired
                               +"</td></tr>";
            }
        }catch(Exception e){
            System.out.println("Error creating company job_applied list "+e);
        }
        if(companyJASList.equals("")){
            companyJASList = "<tr><tr><td>No applications received!</td></tr>";
        }
        return companyJASList;
    }
    
    
    public void updateHired(String jaid){
            //boolean updated = false;

            connection = dataaccess.getConnection();



             try {
                 st = connection.createStatement();
                 String sql = ("UPDATE coop.job_applied SET hired = true WHERE jaid ="+jaid);
                 rs = st.executeQuery(sql);
                 //updated = true;
             } catch(Exception e){
                 System.out.println("Cant read job applied table");
                 //updated = false;
             }

            //return updated;
        }
    
    public String viewSResume(String sid){
            //boolean updated = false;

            connection = dataaccess.getConnection();
            
            ResumeBean rb = new ResumeBean();
            return rb.getResume(sid);



             
        }
    
    
    public String getResumeContent(String jaid){
            
            connection = dataaccess.getConnection();
            String rContent = "";



             try {
                 st = connection.createStatement();
                 String sql = ("SELECT R.content"  
                         + " FROM coop.resume AS R, coop.job_applied AS JA"
                         + " WHERE JA.sid = R.sid AND JA.jaid ="+jaid
                         + " AND R.rid = (SELECT MAX(rid) FROM coop.resume)");
                 rs = st.executeQuery(sql);
                 
                  try{
                    while (rs.next())
                    {
                        
                        rContent = rs.getString("content");
                    }
                    }catch(SQLException e){
                        System.out.println("Error creating content "+e);
                    }
                 
                
             } catch(SQLException e){
                 System.out.println("Cant read resume review/resume table");
        
             }
             
              
             return rContent;
            
        }
    
    
    
    

    
    
    
    
    
    
}
