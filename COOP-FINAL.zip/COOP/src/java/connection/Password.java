/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package connection;

/**
 *
 * @author SVR
 */
public class Password {
    static String pass = "WRITE YOUR PASSWORD HERE";

    public static String getPass()
    {
        return pass;
    }

}
