
package connection;

import dbbeans.ModeratorBean;
import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class DataAccess extends HttpServlet
{

    private Connection connection;
    private Statement st;
    private ResultSet rs;

    public DataAccess()
    {
    }
    
    public Connection getConnection()
    {
        return connection;
    }    
    

    public void openConnection() {
        try
        {
            Password password = new Password();

            Class.forName("org.postgresql.Driver");
            //connection = DriverManager.getConnection("jdbc:postgresql://web0.site.uottawa.ca:15432/zwang143","zwang143","Wang1994");
            //connection = DriverManager.getConnection("jdbc:postgresql://stampy.db.elephantsql.com:5432/fqcjjqzs", "fqcjjqzs", "Aq9AIVTxaJJJmQW6iAeiGNuxQsKP9GqL" );
            connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres", "postgres", "asdf");
            st = connection.createStatement();
            String sql 
                    = "SELECT mid, mfname, mlname FROM coop.moderator";
            rs = st.executeQuery(sql);
            while(rs.next()){
                int mid = rs.getInt("mid");
                String mfname = rs.getString("mfname");
                String mlname = rs.getString("mlname");
                System.out.println("ID: " 
                        +mid+ " Moderator First Name: " 
                        +mfname+ " Moderator Last Name: "
                        +mlname);
 
            }
            
                   
            
            System.out.println("Connection Established");
        }catch(Exception e){
            System.out.println("No connection established: "+e.toString());
        }
    }


    

    public boolean siguiente() {
        try {
            return (rs.next());
        } catch(Exception e){
            System.out.println("Error moving to the next one");
            return false;
        }
    }


    public String getField(String name){
        try {
            return (rs.getString(name));
        } catch(Exception e){
            System.out.println("Error getting the field");
            return "";
        }
    }
    

   public void closeConsult(){
        try {
            rs.close();
            st.close();
        } catch(Exception e){}
    }

    public void closeConnection() {
        try {
            connection.close();
        } catch (Exception e){}
    }
    
    
   public static void main(String[] args){
        
        try
        {
            Password password = new Password();

            Class.forName("org.postgresql.Driver");
            //Connection connection = DriverManager.getConnection("jdbc:postgresql://web0.site.uottawa.ca:15432/zwang143","zwang143","Wang1994");
            //Connection connection = DriverManager.getConnection("jdbc:postgresql://stampy.db.elephantsql.com:5432/fqcjjqzs", "fqcjjqzs", "Aq9AIVTxaJJJmQW6iAeiGNuxQsKP9GqL" );
            Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres", "postgres", "asdf");
            Statement st = connection.createStatement();
            //String sql 
            //        = "SELECT mid, mfname, mlname FROM coop.moderator";
            //ResultSet rs = st.executeQuery(sql);
            
//            while(rs.next()){
//                int mid = rs.getInt("mid");
//                String mfname = rs.getString("mfname");
//                String mlname = rs.getString("mlname");
//                System.out.println("ID: " 
//                        +mid+ "   Moderator First Name: " 
//                        +mfname+ "   Moderator Last Name: "
//                        +mlname);
// 
//            }


            
      
           
            String sql = ("SELECT J.jid, C.cpname, J.jname, J.jlevel, J.numpos, J.jdesp FROM coop.student AS S, coop.job AS J, coop.company AS C WHERE J.cpid = C.cpid AND J.category = S.major AND S.sid = 1234567");
            ResultSet rs = st.executeQuery(sql);
    

            while(rs.next()){
         
      
                
                int jid = rs.getInt("jid");
                int numpos = rs.getInt("numpos");
                String jname = rs.getString("jname");
                String cpname = rs.getString("cpname");
                String jlevel = rs.getString("jlevel");
                String jdesp = rs.getString("jdesp");
                
                String studentJobList="";
                
               
                    studentJobList+="<tr><tr><td>"
                               + "<p><input <c:out type=\"${radio}\"/>"
                               + "<c:out name=\"${rdJobApply}\"/>" 
                               + "<c:out value=\"${Apply}\"/>"
                               + "></p>"
                               + "</td><td>"
                               + jid
                               + "</td><td>"
                               + cpname
                               + "</td><td>"
                               + jname
                               + "</td><td>"
                               + jlevel
                               + "</td><td>"
                               + numpos
                               + "</td><td>"
                               + jdesp
                               +"</td></tr>";
                
                
//                System.out.println("Apply: " + 
//                        +mid+ "   Moderator First Name: " 
//                        +mfname+ "   Moderator Last Name: "
//                        +mlname);
                System.out.println(studentJobList);
 
            }
            
            
      
            
            rs.close();
            st.close();
            connection.close();
        }catch (Exception e){
            System.out.println("Connection Error" + e.getMessage());
        }
        
        
        

    
    
    }
    
    
    

   
}

