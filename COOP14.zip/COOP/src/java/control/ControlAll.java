/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

import dbbeans.*;
import connection.DataAccess;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

/**
 *
 * @author bomby
 */
public class ControlAll extends HttpServlet {
    
     private void processAction(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException
    {
            //HttpSession s = request.getSession(true);
            
            RequestDispatcher rd;
 
            
            
            if(request.getParameter("saveM") != null){
                rd = this.getServletContext().getRequestDispatcher("/index.jsp");
            }else if(request.getParameter("saveC") != null){
                rd = this.getServletContext().getRequestDispatcher("/index.jsp");
                
            }else if(request.getParameter("saveS") != null){
                rd = this.getServletContext().getRequestDispatcher("/index.jsp");
          
            }else if(request.getParameter("cmdApplyJob")!= null){
                
                rd = this.getServletContext().getRequestDispatcher("/display_company_ja.jsp");
            }else if(request.getParameter("cmdComapnyJA") != null){
                rd = this.getServletContext().getRequestDispatcher("/display_company_ja.jsp");
                
            }else {
                rd = this.getServletContext().getRequestDispatcher("/error.jsp");
            }
            
            //RequestDispatcher rd = this.getServletContext().getRequestDispatcher("/menu.jsp");
            
            

                
            rd.forward(request,response);
            
            
 }

    public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException
    {
        processAction(request,response);
    }

    
    public void destroy()
    {       
        super.destroy();
    }
    
    
}
