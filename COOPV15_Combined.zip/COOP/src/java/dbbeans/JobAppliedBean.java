/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbbeans;

/**
 *
 * @author bomby
 */
import connection.DataAccess;
import java.sql.*;

/**
 *
 * @author Panda
 */
public class JobAppliedBean {
    
    private Connection connection;
    private Statement st;
    private ResultSet rs;
    private DataAccess dataaccess;
    private String jobAppliedList = "";
    private String studentJAList = "";
    
    private String companyJASList = "";
    //private String[] loginStudent;
    
    
    private int jaid;
    private int sid;
    private int jid;
    private int cpid;


    
    
    
    
    public JobAppliedBean() {
    }
    
    public void setDataAccess(DataAccess db)
    {
        dataaccess = db;
    }
    
    
    public void setJaid(int value)
    {
        jaid = value;
    }

    public int getJaid()
    {
        return jaid;
    }
    
    public void setCpid(int value)
    {
        cpid = value;
    }

    public int getCpid()
    {
        return cpid;
    }
    
    public void setSid(int value)
    {
        sid = value;
    }

    public int getSid()
    {
        return sid;
    }
    
    public void setJid(int value)
    {
        jid = value;
    }

    public int getJid()
    {
        return jid;
    }
    

   
    public int existsJA(String id) {
        int tmpId = -1;
        String temp;
        
        connection = dataaccess.getConnection();

        try{
            st = connection.createStatement();
            rs  = st.executeQuery("SELECT * FROM coop.job_applied");
            while (rs.next())
            {
                temp = rs.getString("jaid");
                temp = temp.trim();
                if (temp.compareTo(id.trim())==0)
                    tmpId = Integer.parseInt(id);
            }
            rs.close();
            st.close();
            }catch(Exception e){
                System.out.println("Cant read from job_applied table");
            }
            return tmpId;
    }

    public int insertJA(int jaid, int sid, String jid, int cpid)
    {
        connection = dataaccess.getConnection();
        int id = 0;        

        try {
            st = connection.createStatement();

            rs  = st.executeQuery("SELECT max(jaid) as id FROM coop.job_applied");
            rs.next();

            int max_id = rs.getInt(1);
            id = max_id + 1;

            System.out.println("ID: "+id);

            st.executeUpdate("INSERT INTO coop.job "
                            + " (jaid, sid, jid, cpid) "+ 
                    "VALUES (" + 
                    jaid+"," + 
                    sid+ "," + 
                    jid + "," + 
                    cpid + ")");

            rs.close();
            st.close();
        }catch(Exception e){
            System.out.println("Cant insert into job_applied table");
        }
        return id;
    }
    
    public String getJAList()
    {
        connection = dataaccess.getConnection();
        
        int jaid;
        int sid;
        int jid;
        int cpid;

        try {
            st = connection.createStatement();
            rs = st.executeQuery(
                    "SELECT * FROM coop.job_applied");
        } catch(Exception e){
            System.out.println("Cant read job_applied table");
        }
        try{
            while (rs.next())
            {
                jaid = rs.getInt("jaid");
                sid = rs.getInt("sid");
                jid = rs.getInt("jid");
                cpid = rs.getInt("cpid");
           
                
 
                
                jobAppliedList+="<tr><tr><td>"
                               + jaid
                               + "</td><td>"
                               + sid
                               + "</td><td>"
                               + jid
                               + "</td><td>"
                               + cpid
                               +"</td></tr>";
            }
        }catch(Exception e){
            System.out.println("Error creating table "+e);
        }
        return jobAppliedList;
    }
    
    public String getStudentJAList(String sid)
    {
        connection = dataaccess.getConnection();
        
        int jaid;
        int jid;
        String cpname;
        String jname;

    
        

        try {
            st = connection.createStatement();
            rs = st.executeQuery(
                    "SELECT JA.jaid, JA.jid, C.cpname, J.jname " +
                    "FROM coop.job AS J, coop.company AS C, coop.student AS S, coop.job_applied AS JA " +
                    "WHERE JA.jid = J.jid AND JA.cpid = C.cpid AND JA.sid = S.sid AND S.sid =" +sid);
        } catch(Exception e){
            System.out.println("Cant read from Student/Job/Company tables");
        }
 
        try{
            while (rs.next())
            {
                jaid = rs.getInt("jaid");
                jid = rs.getInt("jid");
                cpname = rs.getString("cpname");
                jname = rs.getString("jname");
            
        
 
                
                studentJAList+="<tr><tr><td>"
                               + jaid
                               + "</td><td>"
                               + jid
                               + "</td><td>"
                               + cpname
                               + "</td><td>"
                               + jname
                               +"</td></tr>";
            }
        }catch(Exception e){
            System.out.println("Error creating student job_applied list "+e);
        }
        return studentJAList;
    }
    
    public String getCompanyJASList(String cpid, String jid_str)
    {
        connection = dataaccess.getConnection();
        
        int jaid;
        int jid;
        String jname;
        int sid;
        String email;
        String lname;
        String fname;
        String year;
        String major;

    
        

        try {
            st = connection.createStatement();
            rs = st.executeQuery(
                    "SELECT JA.jaid, JA.jid, J.jname, S.sid, S.email, S.lname, S.fname, S.year, S.major " +
                    "FROM coop.job AS J, coop.company AS C, coop.student AS S, coop.job_applied AS JA " +
                    "WHERE JA.sid = S.sid AND JA.cpid = C.cpid  AND C.cpid =" +cpid+
                    "JA.jid =" +jid_str);
        } catch(Exception e){
            System.out.println("Cant read from Student/Job/Company tables");
        }
 
        try{
            while (rs.next())
            {
                jaid = rs.getInt("jaid");
                jid = rs.getInt("jid");
                jname = rs.getString("jname");
                sid = rs.getInt("sid");
                email = rs.getString("email");
                lname = rs.getString("lname");
                fname = rs.getString("fname");
                year = rs.getString("year");
                major = rs.getString("major");
            
        
 
                
                companyJASList+="<tr><tr><td>"
                               + jaid
                               + "</td><td>"
                               + jid
                               + "</td><td>"
                               + jname
                               + "</td><td>"
                               + sid
                               + "</td><td>"
                               + email
                               + "</td><td>"
                               + lname
                               + "</td><td>"
                               + fname
                               + "</td><td>"
                               + year
                               + "</td><td>"
                               + major
                               +"</td></tr>";
            }
        }catch(Exception e){
            System.out.println("Error creating company job_applied list "+e);
        }
        return companyJASList;
    }
    
    

    
    
    
    
    
    
}
