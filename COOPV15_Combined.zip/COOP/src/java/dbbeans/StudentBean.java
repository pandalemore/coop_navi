/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbbeans;


import connection.DataAccess;
import java.sql.*;

/**
 *
 * @author Panda
 */
public class StudentBean {
    
    private Connection connection;
    private Statement st;
    private ResultSet rs;
    private DataAccess dataaccess;
    private String studentList = "";
    private String[] loginStudent;
    
    
    private int sid;
    private String lname;
    private String fname;
    private String email;
    private int year;
    private String major;
    private int scid;
    //private int rId;
    
    
    
    
    public StudentBean() {
    }
    
    public void setDataAccess(DataAccess db)
    {
        dataaccess = db;
    }
    
    
    public void setSid(int value)
    {
        sid = value;
    }

    public int getSid()
    {
        return sid;
    }

    public void setlName(String value)
    {
        lname = value;
    }

    public String getlName()
    {
        return lname;
    }
    
    public void setfName(String value)
    {
        fname = value;
    }

    public String getfName()
    {
        return fname;
    }
    
     public void setEmail(String value)
    {
        email = value;
    }

    public String getEmail()
    {
        return email;
    }
    
     public void setYear(int value)
    {
        year = value;
    }

    public int getYear()
    {
        return year;
    }
    
     public void setProgram(String value)
    {
        major = value;
    }

    public String getProgram()
    {
        return major;
    }
    
     public void setScId(int value)
    {
        scid = value;
    }

    public int getScId()
    {
        return scid;
    }
    
//    public void setRId(int value)
//    {
//        rId = value;
//    }
//
//    public int getRId()
//    {
//        return rId;
//    }
    
    
    
    
    


   
    public int existsStudent(String id) {
        int tmpId = -1;
        String temp;
        
        connection = dataaccess.getConnection();

        try{
            st = connection.createStatement();
            rs  = st.executeQuery("SELECT * FROM coop.student");
            while (rs.next())
            {
                temp = rs.getString("sid");
                temp = temp.trim();
                if (temp.compareTo(id.trim())==0)
                    tmpId = Integer.parseInt(id);
            }
            rs.close();
            st.close();
            }catch(Exception e){
                System.out.println("Cant read from student table");
            }
            return tmpId;
    }

    public int insertStudent(String email, String lname, String fname, String year, String major)
    {
        connection = dataaccess.getConnection();
        int id = 0;        

        try {
            st = connection.createStatement();

            rs  = st.executeQuery("SELECT max(sid) as id FROM coop.student");
            rs.next();

            int max_id = rs.getInt(1);
            id = max_id + 1;

            System.out.println("ID: "+id);

            st.executeUpdate("INSERT INTO coop.student "
                            + " (sid, email , lname, fname, scid, year, major) "
                    + "VALUES ("+
                    id+",'" + 
                    email + "','" + 
                    lname + "','" + 
                    fname + "', 1234, " + 
                    year + ",'" + 
                    major + "')"); 

            rs.close();
            st.close();
        }catch(Exception e){
            System.out.println("Cant insert into student table");
        }
        return id;
    }
    
    public String getStudentList()
    {
        connection = dataaccess.getConnection();
        
        int sid;
        String lname;
        String fname;
        String email;
        int year;
        String major;
        int scid;

        try {
            st = connection.createStatement();
            rs = st.executeQuery(
                    "SELECT sid, email , lname, fname, scid, year, major FROM coop.student");
        } catch(Exception e){
            System.out.println("Cant read student table");
        }
        try{
            while (rs.next())
            {
                sid = rs.getInt("sid");
                email = rs.getString("email");
                lname = rs.getString("lname");
                fname = rs.getString("fname");
                scid = rs.getInt("scid");
                year = rs.getInt("year");
                major = rs.getString("major");
                
                studentList+="<tr><tr><td>"
                               + sid
                               + "</td><td>"
                               + email
                               + "</td><td>"
                               + lname
                               + "</td><td>"
                               + fname
                               + "</td><td>"
                               + scid
                               + "</td><td>"
                               + year
                               + "</td><td>"
                               + major
                               +"</td></tr>";
            }
        }catch(Exception e){
            System.out.println("Error creating table "+e);
        }
        return studentList;
    }
    
    public String[] getLoginStudent(String id)
    {
   
        connection = dataaccess.getConnection();
        

        String sid;
        String email;
        String lname;
        String fname;  
        String scid;
        String year;
        String major;
        

        try {
            st = connection.createStatement();
            String sql = ("SELECT sid, email , lname, fname, scid, year, major FROM coop.student WHERE sid =" +id);
            rs = st.executeQuery(sql);
            
           
                try{
                    while (rs.next())
                    {
                        sid = Integer.toString(rs.getInt("sid"));
                        email = rs.getString("email");
                        lname = rs.getString("lname");
                        fname = rs.getString("fname");
                        scid = Integer.toString(rs.getInt("scid"));
                        year = rs.getString("year");
                        major = rs.getString("major");
            


                        loginStudent = new String[7];
                        loginStudent[0] = sid;
                        loginStudent[1] = email;
                        loginStudent[2] = lname;
                        loginStudent[3] = fname;
                        loginStudent[4] = scid;
                        loginStudent[5] = year;
                        loginStudent[6] = major;
                    
                    }
                }catch(Exception e){
                        System.out.println("Error creating table "+e);
                }
            
        }catch(NumberFormatException | SQLException e){
            System.out.println("Cant read moderator table");
        }
        
        return loginStudent;
    }
    
    
    
    
    
    
    
}
