/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbbeans;


import connection.DataAccess;
import java.sql.*;

/**
 *
 * @author bomby
 */
public class CompanyBean {
    
    private Connection connection;
    private Statement st;
    private ResultSet rs;
    private DataAccess dataaccess;
    private String companyList = "";
    private String[] loginCompany;
    private boolean created = false;
    
    private int cpid;
    private String cpname;
    private int jid;
    private int numemployee;
    private int cprating;
    private String cpdesp;
    
    
    
    
    public CompanyBean() {
        created = true;
    }
    
    public boolean checkCreated(){
        return created;
    }
    
    public void setDataAccess(DataAccess db)
    {
        dataaccess = db;
    }
    
    
    public void setCpid(int value)
    {
        cpid = value;
    }

    public int getCpid()
    {
        return cpid;
    }

    public void setCpName(String value)
    {
        cpname = value;
    }

    public String getCpName()
    {
        return cpname;
    }
    
    public void setJId(int value)
    {
        jid = value;
    }

    public int getJId()
    {
        return jid;
    }
    
    
     public void setNumEmployee(int value)
    {
        numemployee = value;
    }

    public int getNumEmployee()
    {
        return numemployee;
    }
    
    public void setCprating(int value)
    {
        cprating = value;
    }

    public int getCprating()
    {
        return cprating;
    }
    
    public void setCpDesp(String value)
    {
        cpdesp = value;
    }

    public String getCpDesp()
    {
        return cpdesp;
    }
    

   
    public int existsCompany(String id) {
        int tmpId = -1;
        String temp;
        
        connection = dataaccess.getConnection();

        try{
            st = connection.createStatement();
            rs  = st.executeQuery("SELECT * FROM coop.company");
            
            while (rs.next())
            {
                temp = rs.getString("cpid");
                temp = temp.trim();
                if (temp.compareTo(id.trim())==0)
                    tmpId = Integer.parseInt(id);
            }
            rs.close();
            st.close();
            }catch(Exception e){
                System.out.println("Cant read from company table");
            }
            return tmpId;
    }

    public int insertCompany(String name, String jid, 
            String numemp, String cprating,
            String cpdesp)
    {
        connection = dataaccess.getConnection();
        int id = 0;        

        try {
            st = connection.createStatement();

            rs  = st.executeQuery("SELECT max(cpid) as id FROM coop.company");
            rs.next();

            int max_id = rs.getInt(1);
            id = max_id + 1;

            System.out.println("ID: "+id);

            st.executeUpdate("INSERT INTO coop.company "
                            + " (cpid, cpname, jid, numemployee, cprating, cpdesp) "
                    + "VALUES ("+
                    id+",'" + 
                    name + "'," + 
                    jid + "," + 
                    numemp + "," + 
                    cprating + ",'" + 
                    cpdesp + "')");

            rs.close();
            st.close();
        }catch(Exception e){
            System.out.println("Cant insert into company table");
        }
        return id;
    }
    
     public String getCompanyList()
    {
        connection = dataaccess.getConnection();
        
        int cpid;
        String cpname;
        int jid;
        int numemployee;
        int cprating;
        String cpdesp;

        try {
            st = connection.createStatement();
            rs = st.executeQuery(
                    "SELECT cpid, cpname, jid, numemployee, cprating, cpdesp FROM coop.company");
        } catch(Exception e){
            System.out.println("Cant read company table");
        }
        try{
            while (rs.next())
            {
                cpid = rs.getInt("cpid");
                cpname = rs.getString("cpname");
                jid = rs.getInt("jid");
                numemployee = rs.getInt("numemployee");
                cprating = rs.getInt("cprating");
                cpdesp = rs.getString("cpdesp");
                
                companyList+="<tr><tr><td>"
                               + cpid
                               + "</td><td>"
                               + cpname
                               + "</td><td>"
                               + jid
                               + "</td><td>"
                               + numemployee
                               + "</td><td>"
                               + cprating
                               + "</td><td>"
                               + cpdesp
                               +"</td></tr>";
            }
        }catch(Exception e){
            System.out.println("Error creating table "+e);
        }
        return companyList;
    }
     
     
     public String[] getLoginCompany(String id)
    {
   
        connection = dataaccess.getConnection();
        

        String cpid;
        String cpname;
        String jid;
        String numemployee;
        String cprating;
        String cpdesp;
        

        try {
            st = connection.createStatement();
            String sql = ("SELECT cpid, cpname, jid, numemployee, cprating, cpdesp FROM coop.company WHERE cpid =" +id);
            rs = st.executeQuery(sql);
            
           
                try{
                    while (rs.next())
                    {
                        cpid = Integer.toString(rs.getInt("cpid"));
                        cpname = rs.getString("cpname");
                        jid = Integer.toString(rs.getInt("jid"));
                        numemployee = Integer.toString(rs.getInt("numemployee"));
                        cprating = Integer.toString(rs.getInt("cprating"));
                        cpdesp = rs.getString("cpdesp");
             
            


                        loginCompany = new String[6];
                        loginCompany[0] = cpid;
                        loginCompany[1] = cpname;
                        loginCompany[2] = jid;
                        loginCompany[3] = numemployee;
                        loginCompany[4] = cprating;
                        loginCompany[5] = cpdesp;
             
                    
                    }
                }catch(Exception e){
                        System.out.println("Error creating table "+e);
                }
            
        }catch(NumberFormatException | SQLException e){
            System.out.println("Cant read moderator table");
        }
        
        return loginCompany;
    }
}
